<?php $__env->startSection('title', 'Ver película'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-4">
            <img src="<?php echo e($pelicula->poster); ?>" alt="">
        </div>
        <div class="col-sm-8">
            <h3><?php echo e($pelicula->title); ?></h3>
            <h5>Año: <?php echo e($pelicula->year); ?></h5>
            <h5>Director: <?php echo e($pelicula->director); ?></h5>
            <p><strong>Resumen: </strong><?php echo e($pelicula->synopsis); ?></p>
            <spam><strong>Estado: </strong></spam>
            <?php if($pelicula->rented): ?>
                <spam>Pelicula actualmente alquilada</spam><p></p>
                <a class="btn btn-danger">Devolver pelicula</a>
            <?php else: ?>
                <spam>Pelicula disponible</spam><p></p>
                <a class="btn btn-primary">Alquilar pelicula</a>
            <?php endif; ?>
            <a class="btn btn-warning" href="/catalog/edit/<?php echo e($pelicula->id); ?>">Editar pelicula</a>
            <a type="button" class="btn btn-dark" href="/catalog">Volver al listado</a>
            <form action="<?php echo e(route('movie.destroy', $pelicula)); ?>" method="POST">

             <?php echo csrf_field(); ?>

            <?php echo method_field('DELETE'); ?>

            <button class=" mt-4 btn btn-danger" type="submit" rel="tooltip" >Eliminar</button>

        </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marvin Espinoza\Desktop\VideoClub2\resources\views/catalog/show.blade.php ENDPATH**/ ?>